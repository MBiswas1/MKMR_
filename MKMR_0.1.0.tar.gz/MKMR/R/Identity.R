#' This function gives us identity matrix of size dd.
#' @param dd is the dimension of the matrix needed
#' @details Returns identity matrix of size dd
#' @export Identity
#' @author Arnab Maity
Identity = function(dd){return(diag(1, nrow=dd))}
